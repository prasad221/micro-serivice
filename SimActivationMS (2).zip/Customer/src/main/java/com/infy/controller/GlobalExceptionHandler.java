package com.infy.controller;



import java.util.HashMap;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;


import com.infy.exceptions.UserNotFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {
	

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Object> invalidargument(MethodArgumentNotValidException e){
		HashMap<String,String> e1= new HashMap<>();
		e.getBindingResult().getFieldErrors().forEach(error->{
			e1.put(error.getField(),error.getDefaultMessage());
		}
				);	
		return ResponseEntity.badRequest().body(e1);
	}
	
	@ExceptionHandler(UserNotFoundException.class)
	public String handleBusinessException(UserNotFoundException e){
		return e.getMessage();

	}
}
