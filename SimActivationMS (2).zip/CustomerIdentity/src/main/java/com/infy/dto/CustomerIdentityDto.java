package com.infy.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

public class CustomerIdentityDto {
	
	@NotNull(message = "DOB canot be null")
	@JsonFormat(pattern ="yyyy-MM-dd",shape=Shape.STRING)
	@Pattern(regexp="^\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])$",message="date pattern should be yyyy-mm-dd")
	private String dateOfBirth;
	
	
	@Size(max=15, message="firstName should be maximum of 15 characters")
	@NotBlank(message = "firstName canot be blank")
	private String firstName;
	
	
	@Size(max=15, message="Lastname should be maximum of 15 characters")
	@NotBlank(message="lastName cannot be blank")
	private String lastName;
	
	
	@Length(max=16)
	@Pattern(regexp="\\d{16}",message="uniqueId Number must have 16 Digits")
	private String uniqueIdNumber;
	
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public CustomerIdentityDto()
	{
		
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUniqueIdNumber() {
		return uniqueIdNumber;
	}
	public void setUniqueIdNumber(String uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public CustomerIdentityDto(
			@NotNull(message = "DOB canot be null") @Pattern(regexp = "^\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])$", message = "date pattern should be yyyy-mm-dd") String dateOfBirth,
			@Size(max = 15, message = "firstName should be maximum of 15 characters") @NotBlank(message = "firstName canot be blank") String firstName,
			@Size(max = 15, message = "Lastname should be maximum of 15 characters") String lastName,
			@Length(max = 16) @Pattern(regexp = "\\d{16}", message = "uniqueId Number must have 16 Digits") String uniqueIdNumber) {
		super();
		this.dateOfBirth = dateOfBirth;
		this.firstName = firstName;
		this.lastName = lastName;
		this.uniqueIdNumber = uniqueIdNumber;
	}



}
