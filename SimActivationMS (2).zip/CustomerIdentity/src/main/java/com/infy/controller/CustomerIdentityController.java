package com.infy.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.infy.dto.CustomerIdentityDto;
import com.infy.dto.SimDetailsDto;

import com.infy.service.IdProofValidationService;


//@RestController
public class CustomerIdentityController {

	
	 
	
//1.Customer ID Proof Validation
	
	@Autowired
	private IdProofValidationService validid;
	
	@PostMapping("/customer_id_validation")
public  ResponseEntity<SimDetailsDto> Updatedetails(@Valid @RequestBody  CustomerIdentityDto  cdip) throws Exception 
	{
		SimDetailsDto obj=validid.simActive(cdip);
			
		return new ResponseEntity<>(obj,HttpStatus.OK);
}

}

