package com.infy.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.infy.dto.CustomerAddressDto;
import com.infy.entity.CustomerAddress;
import com.infy.service.UpdateCustomerAddressService;


@RestController
public class AddressController {

// 1.Update Customer Address
	@Autowired
	private UpdateCustomerAddressService custdetails;
	
	@PutMapping("/update_customer_address")
	public  ResponseEntity<CustomerAddress> Updatedetails(@Valid @RequestBody  CustomerAddressDto  cdip) throws Exception 
   {
		CustomerAddress obj=custdetails.updateAddress(cdip);
			return new ResponseEntity<>(obj,HttpStatus.OK);
		}
	
}
