package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.entity.Customer;
import com.infy.exceptions.UserNotFoundException;
import com.infy.repository.CustomerRepository;
@Service
public class CustomerPersonalDetailsService {
@Autowired
private CustomerRepository custverif;

public String Customerpersonaldetailsverification(String firstname,String lastname,String email) throws UserNotFoundException {
	Customer obj=custverif.verifypresonaldetails(firstname,lastname);
	if(obj!=null) {
		if(obj.getEmailAddress().equals(email)) {
			return "success";
		}
		else {
			throw new UserNotFoundException("Invalid email details!!");
		}
		
	}
	throw new UserNotFoundException("No customer found for the provided details");

		
	}
}
