package com.infy.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

public class CustomerAddressDto {
	
	@NotEmpty(message="ADDRESS value is required")
	@Length(max=25,message="Address should be maximum of 25 characters")
	private String address;
	
	private String city;
	
	@Pattern(regexp="\\d{6}",message="pincode length must be 6")
	private String pincode;
	
	private String state;
	private int addressId;

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

}
