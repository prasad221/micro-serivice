package com.infy.exceptions;

public class UserNotFoundException extends Exception{

	private static final long serialVersionUID = 7718471289719856903L;

	public UserNotFoundException(String message) {
		super(message);
	}
	 

}
