package com.infy.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infy.dto.CustomerDto;
import com.infy.entity.Customer;
import com.infy.repository.CustomerRepository;

@Service
public class CustomerValidationService {
	@Autowired
	private CustomerRepository custverif;
	
	@Autowired
	private ModelMapper modelMapper;
	
	public Optional<CustomerDto> Customerdetailsverification(String uniqueid,String firstname,String lastname) {
			Customer obj=custverif.verifyidFirstandlast(uniqueid,firstname,lastname);
			CustomerDto obj1=modelMapper.map(obj,CustomerDto.class);
			return Optional.of(obj1);
		
	}
}
