package com.infy.entity;

import javax.persistence.*;

@Entity
@Table(name="CustomerIdentity")
public class CustomerIdentity {
	@Id
	private String dateOfBirth;
	private String firstName;
	private String lastNmae;
	private String emailAddress;
	private String state; 
	private String uniqueIdNumber;
	
	public CustomerIdentity() {
		
	}
	public CustomerIdentity(String dateOfBirth, String firstName, String lastNmae, String emailAddress, String state,
			String uniqueIdNumber) {
		super();
		this.dateOfBirth = dateOfBirth;
		this.firstName = firstName;
		this.lastNmae = lastNmae;
		this.emailAddress = emailAddress;
		this.state = state;
		this.uniqueIdNumber = uniqueIdNumber;
	}
	public String getUniqueIdNumber() {
		return uniqueIdNumber;
	}
	public void setUniqueIdNumber(String uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastNmae() {
		return lastNmae;
	}
	public void setLastNmae(String lastNmae) {
		this.lastNmae = lastNmae;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

}
