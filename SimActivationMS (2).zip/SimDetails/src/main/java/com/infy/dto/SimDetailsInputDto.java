package com.infy.dto;

import javax.validation.constraints.*;


public class SimDetailsInputDto {
	@NotNull(message="SIM NUMBER value is required")
	@Pattern(regexp="\\d{10}",message="Service Number must be 10 Digits")
	@Size(min = 10, max = 10, message = "Service NUMBER SHOULD HAVE 10 DIGITS")
	String serviceNumber;
	@NotNull(message="SIM NUMBER value is required")
	@Pattern(regexp="\\d{13}",message="SIM NUMBER must be 13 Digits")
	@Size(min = 13, max = 13, message = "SIM NUMBER SHOULD HAVE 13 DIGITS")
	String simNumber;
	public String getServiceNumber() {
		return serviceNumber;
	}
	public void setServiceNumber(String serviceNumber) {
		this.serviceNumber = serviceNumber;
	}

	public SimDetailsInputDto(
			@NotNull(message = "SIM NUMBER value is required") @Pattern(regexp = "\\d{10}", message = "Service Number must be 10 Digits") @Size(min = 10, max = 10, message = "Service NUMBER SHOULD HAVE 10 DIGITS") String serviceNumber,
			@NotNull(message = "SIM NUMBER value is required") @Pattern(regexp = "\\d{13}", message = "SIM NUMBER must be 13 Digits") @Size(min = 13, max = 13, message = "SIM NUMBER SHOULD HAVE 13 DIGITS") String simNumber) {
		super();
		this.serviceNumber = serviceNumber;
		this.simNumber = simNumber;
	}
	public String getSimNumber() {
		return simNumber;
	}
	public void setSimNumber(String simNumber) {
		this.simNumber = simNumber;
	}

}
