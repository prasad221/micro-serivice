package com.infy.repository;


import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infy.entity.Customer;

@Repository
public interface CustomerRepository  extends JpaRepository<Customer, String>{
	@Transactional
	@Query(value="SELECT *FROM customer WHERE email_address=:email and date_of_birth=:dob" ,nativeQuery=true)
	Customer verifybasicdetails(@Param("email") String email,@Param("dob")String dob);
	
	@Transactional
	@Query(value="SELECT *FROM customer WHERE first_name=:firstname and last_name=:lastname" ,nativeQuery=true)
	Customer verifypresonaldetails(@Param("firstname") String firstname,@Param("lastname")String lastname);

	@Transactional
	@Query(value="SELECT *FROM customer WHERE unique_id_number=:uniqueid and first_name=:firstname and last_name=:lastname" ,nativeQuery=true)
	Customer verifyidFirstandlast(@Param("uniqueid") String uniqueid,@Param("firstname")String firstname,@Param("lastname")String lastname);
	
	

}
