package com.infy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.infy.entity.CustomerIdentity;

public interface CustomerIdentityRepository extends JpaRepository<CustomerIdentity, String>{
	@Query(value="SELECT *FROM customer_identity WHERE unique_id_number= :uniqueid and first_name=:firstname and last_nmae=:lastname " ,nativeQuery=true)
	CustomerIdentity verifyidfirstandlastname(@Param("uniqueid") String uniqueid,@Param("firstname")String firstname,@Param("lastname")String lastname);

	
	@Query(value="SELECT *FROM customer_identity WHERE date_of_birth LIKE %:dob% " ,nativeQuery=true)
	CustomerIdentity verifydateofbirth(@Param("dob")String dob);

}
