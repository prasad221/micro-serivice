package com.infy.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.infy.dto.SimOffersDto;
import com.infy.entity.SimDetails;
import com.infy.exceptions.UserNotFoundException;
import com.infy.repository.SimDetailsRepository;

@Service
public class SimDetailsService {
	@Autowired
	private SimDetailsRepository simrepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Value("${offers.uri}")
	String offersUri;

	public SimOffersDto simValidation(String SimNo,String ServiceNo) throws UserNotFoundException{
		SimDetails obj= new SimDetails();
			obj=simrepository.findStatus(ServiceNo,SimNo);
			SimOffersDto obj1=new SimOffersDto();
			if(obj!=null) {
				if(obj.getSimStatus().equals("inactive")) {
					SimOffersDto obj2=new RestTemplate().getForObject(offersUri+obj.getSimId(),SimOffersDto.class);
					obj1=modelMapper.map(obj2,SimOffersDto.class);
					}
				if(obj.getSimStatus().equals("active")) {
					throw new UserNotFoundException("SIM already active");
					}
			}
			else { throw new UserNotFoundException("Invalid details,please check again SIM number/Service number!"); }

			return obj1;	
			}
	
	
	
	
}