package com.infy.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infy.dto.CustomerAddressDto;
import com.infy.entity.CustomerAddress;
import com.infy.exceptions.UserNotFoundException;
import com.infy.repository.CustomerAddressRepository;
@Service
public class  UpdateCustomerAddressService {
	@Autowired
	private CustomerAddressRepository custrep;
	
	@Autowired
	private ModelMapper modelMapper;
	
	public CustomerAddress updateAddress(CustomerAddressDto cdto) throws UserNotFoundException {
		
		CustomerAddress obj= new CustomerAddress();
		Optional<CustomerAddress> obj1=custrep.findById(cdto.getAddressId());
		
		if(obj1!=null) {
			obj=modelMapper.map(obj1,CustomerAddress.class);
			obj.setAddress(cdto.getAddress());
			obj.setCity(cdto.getCity());
			obj.setPincode(cdto.getPincode());
			obj.setState(cdto.getState());
			obj.setAddressId(cdto.getAddressId());
			return custrep.save(obj); 
		}
		else {
			obj=modelMapper.map(cdto,CustomerAddress.class);
			return custrep.saveAndFlush(obj);
		}
	
	}
}
